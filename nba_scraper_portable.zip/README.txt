NBA Unified Scraper - Portable Package
======================================
1. pip install -r requirements.txt
2. Edit .env with your DATABASE_URL
3. python src/scrapers/nba_unified_scraper.py
